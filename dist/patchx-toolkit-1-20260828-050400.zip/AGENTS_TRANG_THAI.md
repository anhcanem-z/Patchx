# AGENTS_TRANG_THAI.md — File trạng thái tổng hợp duy nhất (agent)

Ngày cập nhật: **2026-08-28 00:40 (Asia/Ho_Chi_Minh)** — bản behavior + Frida
`/storage/emulated/0/Patch/patch1/_patchx`, chạy độc lập với bản `w/`.

---

## 0. ƯU TIÊN SỐ 1 KHI MỞ CODEX + QUY TẮC TỰ CẬP NHẬT (bắt buộc)

### 0.1 Ưu tiên số 1 khi mở Codex
1. **Bước đầu tiên của mọi phiên**: quét ngay file này (`AGENTS_TRANG_THAI.md`)
   để nạp toàn bộ dữ liệu trạng thái — không làm việc khác trước bước này.
2. Kiểm tra xem toolkit có thay đổi không (mtime các báo cáo, số liệu mới
   trong `outputs/audit/audit.json`, `outputs/baseline/metrics.json`,
   `outputs/**/*`, `outputs/apk/apk-patch/`, `outputs/behavior/`).
3. Nếu có thay đổi → **cập nhật ngay file này** theo mục 0.2 trước khi xử lý
   yêu cầu của người dùng; nếu chưa chắc, chạy lệnh đo ở mục 3 để lấy số thật.
4. **Báo cáo tự động khi online**: chỉ khi phiên Codex đang nằm trong thư mục
   toolkit (`cwd` trong `_patchx`) — chạy `python3 tools/status_report.py` rồi
   trình cho người dùng **A. Thông tin cơ bản** + **B. Thành phần cần bổ
   sung**. Nếu mở ngoài thư mục toolkit thì không báo tình trạng toolkit.
5. Chỉ sau khi file đã đồng bộ với hiện trạng và đã báo cáo mới bắt đầu nhiệm
   vụ chính.
6. **Giới hạn phạm vi toàn cục**: TOÀN BỘ Codex (mọi phiên, mọi công cụ) chỉ
   hoạt động trong phạm vi **thư mục làm việc hiện tại và các thư mục con của
   nó** (dự án này: `_patchx` + thư mục con) — trong phạm vi này được đọc/ghi/
   thao tác đầy đủ; **ngoài phạm vi (Modder Hub, `patch1/` worklist,
   `Download/`...) CHỈ ĐƯỢC ĐỌC (read-only)**: không ghi/sửa/xóa/tạo file,
   không chạy lệnh gây thay đổi dữ liệu; muốn ghi/tác động ngoài phạm vi phải
   được người dùng yêu cầu rõ, chỉ tác động đúng phạm vi được yêu cầu.

### 0.2 QUY TẮC TỰ CẬP NHẬT (bắt buộc đối với AI)
1. **Khi nào cập nhật** — mỗi khi toolkit có thay đổi thuộc một trong các nhóm:
   - Chạy lại số đo: `tests/run_tests.py`, `patchx ci`, `patchx audit`,
     `patchx simulate`, `patchx golden`, `baseline capture`.
   - Thay đổi code/lệnh/module: thêm, xóa, sửa lệnh `patchx` hoặc
     `patchx_toolkit.py`, module trong `patchx_core/`, `patchx_core/behavior/`,
     tests.
   - Thay đổi dữ liệu: thêm/xóa patch trong `upgraded/`, `combos/`,
     `combos_auto/`, APK/cây APK mới, kết quả `apk-full`, `apk-build`,
     `apk-patch`, behavior/gadget.
   - Kết quả mới: build/ký APK, audit, CI, benchmark, bug root-cause mới đã
     sửa, runtime M2/M3.
2. **Cập nhật gì** — số liệu mới nhất kèm ngày giờ, trong đúng mục tương ứng;
   giữ nguyên cấu trúc mục của file này; đừng xóa dữ liệu cũ — dời vào
   **mục 9 (Mốc cập nhật + lịch sử)**.
3. **Ràng buộc viết** — tiếng Việt; giữ nguyên danh từ/chuỗi gốc (khóa patch,
   regex, smali, tên biến, tên tệp); chỉ ghi số liệu **đã chạy thực tế**,
   không ước lượng, không bịa; kết luận phải có số đo được.
4. **Sau khi cập nhật** — sửa dòng "Ngày cập nhật" ở đầu file + thêm một dòng
   vào mục 9; nếu thay đổi cấu trúc thư mục/lệnh thì cập nhật luôn
   `OPERATIONS/NAVIGATION.json` và `outputs/README.md` nếu liên quan.
5. **Nguồn số liệu hợp lệ** — kết quả thật từ các lệnh ở mục 3; báo cáo
   `outputs/audit/audit.json`, `outputs/baseline/metrics.json`,
   `outputs/**/*report*.json/md`, `outputs/apk/apk-build/*`,
   `outputs/apk/apk-patch/`, `outputs/behavior/`.

---

## 1. TỔNG QUAN KPI NHANH (mốc 2026-08-14 → 2026-08-21)

| Chỉ số | Giá trị mới nhất | Ngày đo |
|---|---|---|
| Selfcheck | **8/8 module OK, 60 patch đọc được, 0 lỗi** | 2026-08-21 |
| Test đơn vị | **chưa chạy hết** — dừng ở `test_bypass_advisor` (`KeyError: cách_công_cụ` — test dùng key có dấu, code dùng `cach_cong_cu`; lỗi có sẵn bản này). Mốc cũ: 52/52 (14/08), 174/174 (16/08). Nhóm mới: `smart_ontology` **29/29** (thêm 7 hành vi MT Protect) + `smart_scanner` 26/26 + `behavior_aux` 4/4 (chạy lại 2026-08-21 16:37); mốc cũ nhóm mới: `smart_ontology` 17/17 + `start_scan` 7/7 + `feature_menu` 21/21 + `rodata_patcher` 29/29 + `rodata_bypass` 11/11 = **119/119 pass** (chạy riêng) | 2026-08-21 |
| Bộ patch chuẩn hóa | **60 zip** trong `upgraded/` | 2026-08-21 |
| Audit | **60 patch — 0 lỗi / 18 cảnh báo / 17 vấn đề tự sửa được** (`outputs/audit/audit.json`) | 2026-08-21 |
| APK đầu vào | **7 APK** trong `Apks/` (Live Translator 172M, Mango 91M, app.apk 79M, app.objection 71M, app1.apk 32M, dich.apk 122M, test.apks 153M) | 2026-08-21 |
| Cây giải mã | **2 cây** trong `outputs/apk/apk-trees/` (app — 699M, app1 — 377M) | 2026-08-21 |
| Combo thành công | **4 lượt** trong `outputs/combos/combos_success.json` (1 lượt 2026-08-20 + 3 lượt 2026-08-21) | 2026-08-21 |
| Git | **đã init + push GitHub** — commit đầu `125a7a3` nhánh `master` → `anhcanem-z/Behavior-` (241 file; loại `outputs/`, `Apks/`, `dist/`, `.codex/`, `libso/`) | 2026-08-21 |
| Bản phân phối | **3 bản** trong `dist/` (mới nhất: patchx-toolkit-10-20260821-143407.zip, 11.93 MB) | 2026-08-21 |

---

## 2. CẤU TRÚC TOOLKIT + BẢN ĐỒ TÀI NGUYÊN (hiện trạng trên đĩa)

### 2.1 Thành phần chính
- `patchx` — CLI chính: behavior/targets/behavior-pipeline/gadget-pipeline/
  scan/index/dupes/manifest/verify-manifest/report/ci/golden/validate/
  apk-prepare/audit/upgrade/optimize/apply/test/dex-budget/preflight/fuzz/
  failure/baseline/coverage/suggest/analyze/model/semantic-plan/acceptance/
  knowledge/plan-compile/plan-preflight/remote-map/remote-patch/
  remote-observe/rodata-find/rodata-patch/rodata-apply/menu/diff-apk/suggest-apk/suggest-llm/roadmap/simulate/selfcheck/
  pairip-bypass/
  combo/ui/frida/stats/clean.
- `patchx_toolkit.py` — orchestrator: doctor/run/package/list/session/apk-plan/
  apk-test/apk-fix-res/apk-patch/apk-debug/apk-build/apk-full/apk-runtime/
  bench-scan/plan-ui/webui/install-deps.
- `patchx_core/` — **36 module** + gói con `behavior/` (45 file): detector,
  target, cfg, ontology, model, patcher, pipeline, gadget_pipeline,
  frida_generator, crypto_interceptor, remote_controller, rodata_patcher,
  flows, behavior_learner (TỰ ĐỘNG ghi hành vi mới khi quét APK/lib) + bản sao
  module lõi (advisor, baseline, engine, cli, ...) + **gói riêng
  `rodata_bypass/`** (static_flow + dynamic_flow + main hiển thị riêng).
- `tests/` — `run_tests.py` + `fixtures/`.
- `tools/` — `status_report.py` (báo cáo tự động khi online),
  `sync_modules.py` (kiểm tra đồng bộ module khi thêm tính năng/nâng cấp).
- `OPERATIONS/` — lớp điều hướng hiển thị; đường dẫn thật khai báo trong
  `NAVIGATION.json` (không chứa bản sao).
- Docs ưu tiên giữ: `HUONG_DAN_LENH.txt`, `HUONG_DAN_BEHAVIOR_FRIDA.txt`,
  `HUONG_DAN_GADGET.txt`; docs lịch sử: `README.md`, `NGU_CANH.md`,
  `UPGRADE_PLAN_V3.md`, `EVALUATION.md`.
- Script dev: `sync_patchx.py`, `sync_imports.py`, `upgrade_behavior.py`.

### 2.2 Bản đồ khối tài nguyên (số liệu đếm thật trên đĩa 2026-08-21)

| Thư mục | Nội dung | Số lượng |
|---|---|---|
| `Apks/` | APK đầu vào gốc | **0 hiện tại** (đã dọn khỏi bản này; trước đây 7 APK) |
| `upgraded/` | Patch chuẩn hóa (nguồn chính) | **60 zip** |
| `combos/` | Combo chính (sinh ra khi chạy `combo`) | **0 hiện tại** |
| `combos_auto/` | Combo tự phát hiện | **0 hiện tại** |
| `outputs/apk/apk-trees/` | Cây giải mã | **2 cây** (app — 699M, app1 — 377M) |
| `outputs/apk/apk-build/` | APK build nhanh + báo cáo | 5 tệp (APK ~84M + report) |
| `outputs/apk/apk-patch/` | APK đã patch + keystore debug | patchx-debug.keystore |
| `outputs/behavior/` | Artifact behavior/Frida | 5 tệp (generated_hook.js, frida_hooks_config.json, ...) |
| `outputs/behavior/gadget/` | APK nhúng gadget + keystore | app_signed/unsigned/aligned + libgadget.so (25M) + gadget_debug.keystore |
| `outputs/combos/` | Kho combo thành công | combos_success.json (**4 lượt**) |
| `outputs/backup/` | Bản lưu trước khi đổi cấu trúc | `pre_sync_20260821/` (11 tệp source gốc) |
| `outputs/` | File tự sinh + output module | scan/, audit/, roadmap/, simulate/, ci/, golden/, bench/, baseline/, backup/, cache/, combos/, pipeline/, apk/, behavior/ (xem `outputs/README.md`) |
| `dist/` | Bản phân phối | 3 bản (v8/v9/v10; mới nhất v10-20260821-143407.zip 11.93 MB) |

---

## 3. LỆNH ĐO + NGUỒN SỐ LIỆU (chạy thực tế để cập nhật)

| Mục | Lệnh | Ghi vào |
|---|---|---|
| Selfcheck | `python3 patchx selfcheck` | stdout |
| Test | `python3 -B tests/run_tests.py` | stdout |
| Audit | `python3 patchx audit upgraded -o outputs/audit` | `outputs/audit/audit.json` + `audit_report.md` |
| Scan/index | `python3 patchx index upgraded -o outputs/scan` | `outputs/scan/patchx_index.json` + `patchx_report.md` |
| Simulate | `python3 patchx simulate upgraded -o outputs/simulate` | `outputs/simulate/simulation.json` + `simulation_report.md` |
| CI | `python3 patchx ci upgraded -o outputs/ci` | `outputs/ci/ci_report.json` + `ci_report.md` |
| Golden | `python3 patchx golden -o outputs/golden` | `outputs/golden/golden_gate.json` |
| Baseline | `python3 patchx baseline capture --dir outputs/baseline` | `outputs/baseline/metrics.json` |
| Roadmap | `python3 patchx roadmap .. CÂY -o outputs/roadmap` | `outputs/roadmap/roadmap.json` + `roadmap.md` |
| Pipeline | `python3 patchx_toolkit.py run` | `outputs/pipeline/` |
| Package | `python3 patchx_toolkit.py package --output dist` | `dist/patchx-toolkit-*.zip` (giữ 3 bản) |

---

## 4. NHÓM BEHAVIOR + FRIDA + GADGET (đặc thù bản này)

- `patchx behavior CÂY` — phân tích hành vi APK dựa trên bằng chứng.
- `patchx targets CÂY` — xác định mục tiêu cần sửa.
- `patchx behavior-pipeline CÂY -o outputs/behavior` — detector → cfg → target
  → hook → frida → loader → APK; `--auto-patch`, `--build-apk`,
  `--interactive`, `--min-score`.
- `patchx gadget-pipeline APK -o outputs/behavior/gadget` — nhúng Frida Gadget
  vào APK/cây (không root); `--gadget-mode script|listen`, `--gadget-path`,
  `--keystore`, `--no-sign`.
- `patchx remote-map CÂY --flow/--dataflow` — bản đồ luồng quyết định/dữ liệu.
- `patchx remote-patch MAP --set ...` — sinh patch ép flag.
- `patchx remote-observe PKG --hook outputs/behavior/generated_hook.js` — quan
  sát + điều khiển từ xa qua Frida (spawn/attach).
- `patchx rodata-find FILE.SO --string CHUỖI` — tìm RVA chuỗi trong
  `.rodata`/`.data` của file `.so` (thay bước tay bằng IDA/Ghidra).
- `patchx rodata-patch FILE.SO --string CHUỖI --new CHUỖI_MỚI [--offset RVA]
  [--ptr-offset RVA] [--mode inline|pointer|both] [--runtime-scan]` — sinh
  script Frida patch chuỗi `.rodata` trên RAM (không sửa file gốc): bảo vệ
  trang rwx → ghi inline (kiểm tra dung lượng) hoặc đổi con trỏ tới chuỗi
  mới cấp phát (độ dài vô hạn) → khôi phục quyền trang; script mặc định tại
  `outputs/behavior/rodata_patch.js`.
- **Bộ bypass riêng**: `patchx_core/rodata_bypass/` — thư mục module
  riêng (StaticBypassFlow + DynamicBypassFlow) + `main.py`/`rodata_bypass_main.py`
  (main hiển thị riêng, banner 2 luồng); chạy `python3 rodata_bypass_main.py
  FILE.SO --flow static|dynamic ...` — tách biệt hoàn toàn khỏi CLI cũ.
- `patchx rodata-apply FILE.SO --string CHUỖI --new CHUỖI_MỚI
  [--allow-overflow] [--no-backup] [--out FILE]` — chèn chuỗi TRỰC TIẾP vào
  file `.so` (patch file, không cần Frida): tự tìm RVA → ghi tại offset thật
  + NUL hóa phần dư, backup gốc vào `outputs/backup/rodata_apply/`; chặn
  chuỗi dài hơn chuỗi cũ trừ `--allow-overflow` (giới hạn cố hữu patch file,
  khác Frida RAM — muốn thay chuỗi dài hơn dùng `rodata-patch --mode
  pointer`). Không hỗ trợ mode pointer/runtime_scan khi patch file.
- **Quét .so thông minh**: `patchx_core/behavior/smart_scanner.py` (4 trụ cột:
  lọc nhiễu ngữ nghĩa — api_key/token/endpoint/header/class JNI/cipher vs
  log/comment/sample/symbol/library; static data-flow — ADRP+ADD/LDR literal
  (ARM64), LEA rip/mov imm64 (x86_64), absolute fallback, symbol table, đồ thị
  gọi BL/CALL, phát hiện ghép/xor động; xác thực chéo caller/callee + danh
  sách hàm hệ thống — loại false positive; Risk Weighting + Confidence
  0-100 kèm EVIDENCE + SHA-256 repro) + `smart_ontology.py` (TỪ ĐIỂN HÀNH VI
  giống ontology.py: hardcoded_secret, endpoint_exposure,
  dynamic_endpoint_build, sensitive_header, encoded_payload,
  jni_class_reference, jni_flow_string, format_dynamic_param, path_exposure,
  log_noise, sample_noise, symbol_noise, library_noise, other_behavior).
- `patchx smart-scan FILE.SO [--min-risk N] [--show-noise] [--behaviors]
  [-o json] [--md md]` — quét 1 file .so; `patchx start-scan APK|THƯ_MỤC|
  FILE.SO [--abi ...] [--keep-so]` (alias `start_scan`) — start-scan = xử lý
  THƯ VIỆN lib .so HÀNG LOẠT (tách biệt: behavior = smali): trích lib/*.so
  theo ABI từ APK, quét từng lib, tổng hợp top findings + bảng từng lib
  (sha256, refs, JNI, nhiễu); đầu ra `outputs/behavior/smart_scan/`.
- Menu chức năng (`patchx menu`) phân chia NHÁNH nền tảng có hệ thống:
  NHÁNH 1 NATIVE (.so) → NHÁNH 2 SMALI → NHÁNH 3 CHUNG; trong nhánh theo
  bước luồng; đánh số liên tục, badge `[.so]`/`[smali]`/`[chung]`.
- Đầu ra mặc định đã đồng bộ: `outputs/behavior/` (artifact hook) +
  `outputs/behavior/gadget/` (APK + libgadget.so + keystore).
- Tài nguyên: `libgadget.so` gốc ở thư mục gốc (25M, trùng bản trong
  `outputs/behavior/gadget/`); `frida-termux-build/` là bản build tạm (117M).
- Chi tiết: `HUONG_DAN_BEHAVIOR_FRIDA.txt`, `HUONG_DAN_GADGET.txt`.

---

## 5. LỖI ĐÃ GẶP + CÁCH XỬ LÝ (bản này)

- **Test dừng giữa chừng do cache cũ schema** (TMP/patchx_sim_cache dùng key
  `trạng_thái` có dấu, code mới dùng `trang_thai`) → xóa thư mục cache cũ
  trong `/data/data/com.termux/files/usr/tmp/` rồi chạy lại. Đã dọn 2026-08-21.
- **Test/code lệch schema key** (`cách_công_cụ` trong test vs `cach_cong_cu`
  trong `patchx_core/bypass_advisor.py`) → lỗi có sẵn, cần sửa đồng bộ
  test hoặc code trước khi có mốc test đầy đủ.
- **`webui` có lệnh nhưng thiếu thư mục `webui/`** → chạy `webui` sẽ lỗi
  thiếu `server.py`; cần bổ sung nếu dùng giao diện web.
- **`python3` (Termux) đã SỬA XONG 2026-08-21 14:12** — trước đó binary 7.5KB
  lỗi ELF header (bản build dở từ `/data/data/com.termux/files/usr/tmp/
  py312build`, ghi nhận 12:21); giờ chạy bình thường: `python3 --version` =
  **Python 3.14.6**, `python3 patchx selfcheck` = 8/8 module OK, 60 patch,
  0 lỗi. Từ giờ dùng `python3` cho mọi lệnh, không cần `python3.12`.
- **ADRP decode sai đơn vị** (smart_scanner 2026-08-21) — imm của ADRP là số
  TRANG (4KB), phải `<< 12`; bản đầu ghi `page + imm` (sai) làm ref trỏ lung
  tung vào .text; test cũ encode sai nên "đúng" cả hai phía. Đã sửa decoder +
  test encode `immlo=1` (0xB0000000) → refs chuẩn (libzstd-jni: 474 refs,
  22 JNI).
- **Regex LIBRARY_MSG_RE có alternative rỗng** (`GNU C\+\+|)`) — khớp MỌI
  chuỗi, làm log/sample nhầm thành library. Đã bỏ `|` cuối.
- **Basic auth regex quá rộng** — "Basic Animated Texture Profile" bị nhận
  nhầm secret; đã siết: token phải chứa chữ số hoặc `+/=`. Đường dẫn build
  (`out/llvm-project/...`) bị nhầm cipher → thêm PATH_PREFIXES kiểm tra
  trước entropy; tên mangled typeinfo (`NSt6__ndk1...`) → symbol noise.
- Đã có git (repo local + remote GitHub `anhcanem-z/Behavior-` từ 2026-08-21); thay đổi chưa commit vẫn nên backup thủ công vào `outputs/backup/` trước khi thao tác.
  trước khi thao tác.

---

## 6. VIỆC TIẾP THEO (ưu tiên)

1. app1.apk bypass: hướng còn lại — (a) tìm + patch nhánh quyết định
   trước RegisterNatives trong JNI_OnLoad (Stalker so sánh 2 luồng gốc/tampered),
   (b) thay hash chứng chỉ nhúng trong .rodata/.data, (c) dump natives thật rồi
   làm stub v2. Không dùng stub sạch / patch abort đơn thuần (đã chứng minh fail).
2. Sửa đồng bộ schema `cách_công_cụ`/`cach_cong_cu` (test/code) để test chạy
   hết, ghi mốc thật vào mục 1.
2. Quyết định xóa/giữ dữ liệu nặng còn lại: `Apks/` (7 APK — ~1.48G),
   `frida-termux-build/` (117M). (Đã xóa: `*.bak`, `libgadget.so` trùng,
   `cli_fixed.py` → `outputs/backup/`.)
3. Đã tạo bản phân phối (dist v4 11.31 MB, 60 zip sạch — agent files +
   `tools/` + `OPERATIONS/` + 3 file `HUONG_DAN_*.txt` trong gói; loại
   `outputs/`, `frida-termux-build/`; bản v1 có bản sao upgraded đã loại).
4. Bổ sung `webui/` nếu cần; cập nhật `outputs/README.md` khi thêm module mới.
5. ~~Sửa `python3` hỏng trên Termux~~ — **ĐÃ XONG** (người dùng sửa, verify
   `python3 --version` = 3.14.6 + selfcheck 8/8 OK ngày 2026-08-21 14:12).
6. Chạy lại `python3 patchx test` đầy đủ sau khi sửa schema để có mốc toàn bộ
   (hiện dừng ở `test_bypass_advisor` — lỗi có sẵn; nhóm mới 119/119 pass).

---

## 7. TÀI LIỆU THAM CHIẾU (đọc khi cần chi tiết)

- `README.md` — toàn bộ lệnh + ví dụ.
- `HUONG_DAN_LENH.txt` — hướng dẫn sử dụng lệnh (ưu tiên giữ).
- `HUONG_DAN_BEHAVIOR_FRIDA.txt` — hướng dẫn nhóm behavior + Frida.
- `HUONG_DAN_GADGET.txt` — hướng dẫn Frida Gadget.
- `NGU_CANH.md` — ngữ cảnh, lịch sử yêu cầu, trạng thái dự án.
- `UPGRADE_PLAN_V3.md` — kiến trúc thế hệ 3 (T1–T7) + lộ trình.
- `EVALUATION.md` — mức đạt theo nhu cầu + bằng chứng đo được.
- `outputs/README.md` — bản đồ thư mục output theo module.

---

## 8. MỐC CẬP NHẬT + LỊCH SỬ

## 8. MỐC CẬP NHẬT + LỊCH SỬ

- 2026-08-28 00:40: CHẨN ĐOÁN CRASH `com.sota.aitranslatex` SAU REBUILD
  (Apktool M) — đã tái hiện + sửa trên VM `100.65.90.24`:
  - Crash: `IllegalStateException: Module with the Main dispatcher is
    missing` (kotlinx-coroutines, `Wb.u`/`Wb.t`) — ngay khi mở app.
  - Nguyên nhân: rebuild MẤT `META-INF/services/Ka.q`, `Rb.L`, `Wb.s`
    (service provider kotlinx-coroutines; `Wb.s`->`Sb.a` = Main dispatcher
    factory) + 8 file `kotlin/*.kotlin_builtins`. Config `apktool.json` chỉ
    ghi 3 file services trong `doNotCompress`, KHÔNG ghi trong `unknownFiles`
    -> build không đóng gói.
  - Sửa: thêm 3 services (STORED) + 8 kotlin_builtins (DEFLATE) vào base
    rebuild, ký lại đồng bộ base+3 splits bằng 1 keystore -> cài VM chạy tốt,
    hết crash, PairIP tắt (không còn log LicenseClient). Đã bổ sung 11 mục
    vào `unknownFiles` của `base/apktool.json` + `base_src/apktool.json`
    (155 -> 166) để build sau giữ file.
  - Chữ ký: base rebuild ký khác splits -> `INSTALL_FAILED_INVALID_APK:
    signatures are inconsistent`; phải ký đồng bộ cả bộ mới cài được.

- 2026-08-27 23:14: THÊM LỆNH `pairip-bypass` — vô hiệu hóa PairIP
  (license check `com.pairip.*`) trên cây APK:
  - Module mới: `patchx_core/behavior/pairip_bypass.py` (schema
    `patchx.pairip-bypass/v1`): `detect_pairip` (tìm smali/com/pairip trong
    smali* + khớp manifest Application/LicenseActivity/CHECK_LICENSE + lib
    native libpairip*), `build_pairip_plan` (7 mục tiêu), `apply_pairip_bypass`
    (`--apply` backup + patch, idempotent), báo cáo JSON+MD tại
    `outputs/behavior/pairip_bypass/`.
  - Vá 7 điểm: bỏ `checkLicense` ở `Application.attachBaseContext` +
    `LicenseContentProvider.onCreate`; nop `LicenseClient.checkLicense`/
    `stopTrial`/`handleTrialEnd`/`initializeLicenseCheck` (return-void);
    `LicenseActivity.onStart` tự `finish()`.
  - Test mới: `test_pairip_bypass` 8/8 pass (chạy riêng; detect + plan +
    apply 7/7 + backup + idempotent + cây không có PairIP).
  - Đã kiểm chứng trên cây APK thật `com.sota.aitranslatex` (đã vá tay
    phiên trước) — plan báo đúng 7/7 "already_patched".
  - Đồng bộ: `HUONG_DAN_LENH.txt` + `AGENTS_TRANG_THAI.md` mục 2.1.

- 2026-08-27 22:30: APP `tool/` v0.18 — OVERLAY + PIP + CHỌN VÙNG NỔI +
  NHẬN DIỆN NGÔN NGỮ + NGÔN NGỮ PHỔ BIẾN + ĐỌC TRỌN ĐOẠN THOẠI:
  - Hiển thị trên app khác: `FloatingTranslateView` (TYPE_APPLICATION_OVERLAY,
    kéo thả, có nút "🎯 Chọn vùng đọc chữ") — service tự bật khi
    `overlay_enabled=true` (pref `app_prefs`), cập nhật theo từng bản dịch,
    tắt khi dừng; cần `SYSTEM_ALERT_WINDOW` (MainActivity tự mở settings nếu
    thiếu; test VM dùng `appops set vn.smartdubbing.live SYSTEM_ALERT_WINDOW allow`).
  - PiP: `MainActivity` thêm `supportsPictureInPicture` + `configChanges`;
    nút "⛶ Thu nhỏ PiP ngay"; tự động vào PiP khi bấm Home lúc đang dịch
    (`onUserLeaveHint`, pref `pip_auto` mặc định true); trong PiP hiện
    `pipText` = bản dịch mới nhất (toàn màn hình che form, exit trả lại form).
  - Chọn vùng NỔI trên app gốc: `RegionSelectOverlay` (full-screen
    TYPE_APPLICATION_OVERLAY dùng lại `RegionSelectView`, nút Huỷ/Lưu) — mở
    từ nút "🎯 Chọn vùng đọc chữ" trong panel OCR (service chưa chạy thì
    MainActivity tự hiện, service đang chạy thì broadcast
    `ACTION_SELECT_REGION` → service hiện); giữ `RegionSelectorActivity` cũ.
  - Panel "⚙ Cài đặt hiển thị" mở NGAY tại chỗ (không thoát màn hình):
    overlay toggle, auto-PiP toggle, nút PiP ngay — áp dụng tức thì qua
    broadcast `ACTION_SET_OVERLAY` + pref.
  - Nhận diện ngôn ngữ: `LangDetect` (đếm ký tự han/kana/hangul/thai/arab/
    devanagari/cyrillic/latin → vi/ja/ko/zh-Hans/th/ar/hi/ru/en); OCR chế độ
    nguồn = "auto" tự chuyển recognizer ML Kit (thêm devanagari) + tự đổi
    ngôn ngữ dịch (`detectedSourceLang`); Google dịch hỗ trợ `sl=auto`.
    ASR không auto được → fallback en (có log). Thêm model Vosk cho ja/ko/
    th/id/hi/ar/tr/it/nl/pl/uk.
  - Thêm ngôn ngữ phổ biến: đích vi/en/ja/ko/zh-Hans/es/fr/th/id/pt/de/ru +
    hi/ar/tr/it/nl/pl/uk/sv/ms/fil/cs/el/fa/bn (voice MS Neural + locale đủ);
    nguồn auto + 20 ngôn ngữ.
  - Đọc TRỌN đoạn thoại: bỏ logic "bỏ N đoạn cũ" (chỉ đọc mấy chữ cuối) →
    gộp các đoạn đang chờ + đoạn mới thành 1 câu đọc đủ (cap 420 ký tự,
    giữ phần mới nhất khi quá dài).
  - Build `gradle :app:assembleRelease` OK — APK 160MB, versionCode 18/
    versionName 0.18. LƯU Ý: user yêu cầu KHÔNG test VM nữa ("khong dung vm
    nua") — phần overlay/PiP/region chỉ mới xác nhận overlay window xuất
    hiện trên VM lúc v0.17, các tính năng v0.18 chưa test thật.

- 2026-08-27 21:55: APP `tool/` v0.17 — TỐI ƯU TỐC ĐỘ XỬ LÝ REAL-TIME
  (áp dụng toàn pipeline OCR + ASR + TTS, test thật trên VM Android 15):
  - Bỏ log đo trễ `+${dt}ms` (user phản đối "log mili giây làm gì") — log
    gọn `OCR mới: ...`, đo trễ bằng timestamp chuẩn `HH:mm:ss.SSS` của `log()`.
  - Tách DỊCH ║ PHÁT song song: `translationLoop` không còn `done.await` chờ
    TTS phát xong; dịch xong đẩy `speakQueue`; `speakLoop` mới phát tuần tự
    từng đoạn (chờ `onDone` thật sự mới đọc đoạn kế — không 2 giọng chồng
    nhau, không trùng tốc độ). Trễ dịch không bị chặn bởi thời lượng phát.
  - Cache dịch `(src|dst|text)` LinkedHashMap 300 — nội dung lặp lại đọc ngay
    không gọi API ("Dịch (cache): ...").
  - Cache audio TTS: Google `gtts_<md5>.mp3` + Microsoft `mstts_<md5>.mp3`
    theo `lang|voice|speed|text`; Google TTS phát STREAMING ngay khi có dữ
    liệu + tải nền vào cache; tự dọn > 80 file.
  - OCR: poll 120→60ms, sleep 100→25ms, image null 300→80ms; bỏ copy
    full-frame 720x1280 → `readCropFromImage` đọc thẳng vùng crop từ buffer
    (đỡ ~70% băng thông/CPU), giữ scale ≤720px.
  - Bỏ trễ 2,5s/chunk khi máy không có engine TTS: cờ `androidTtsChecked` —
    init xong mà không ready → lần sau bỏ hẳn chờ, sang Google TTS ngay
    (lần đầu chỉ chờ tối đa 600ms).
  - `log()` chuyển `appendText` (trước đọc+ghi cả file mỗi dòng), trim khi
    >400KB; `publish()` giữ broadcast tức thì, notification giới hạn 500ms/lần.
  - ASR partial commit 1200→700ms. Build `gradle :app:assembleRelease` OK,
    APK 159MB đã cài lên VM (root@100.65.90.24:8022), log xoá sạch trước test.
  - Test thật OCR đọc Wikipedia: OCR→dịch khởi tạo 3-11ms, bản dịch về
    44-650ms, TTS cache phát lại tức thì, backlog quá tải tự bỏ đoạn cũ ưu
    tiên nội dung mới nhất ("Giọng đọc chậm hơn nội dung — bỏ N đoạn cũ").

- 2026-08-27 18:10: APP ANDROID `tool/` (`vn.smartdubbing.live`) v0.4 —
  DEEPSEEK DỊCH GIỌNG VIDEO THỜI GIAN THỰC (ASR + DeepSeek + giọng Microsoft)
  + GEMINI TỰ ĐỘNG FALLBACK ASR khi lỗi:
  - Pipeline DeepSeek realtime (DeepSeek là text-only): capture audio video
    (MediaProjection + AudioPlaybackCapture 16kHz mono) → Vosk ASR OFFLINE
    (`VoskAsr.kt`, model nhỏ tải 1 lần về `filesDir/vosk/{lang}` từ
    alphacephei: en-us-0.15 / vn-0.4 / ru / fr / de / es / pt / zh-cn) →
    DeepSeek dịch (`deepseek-chat`, prompt ngắn gọn/tự nhiên/giữ tên riêng) →
    giọng Microsoft Edge TTS free đọc.
  - `AudioCaptureService.kt` viết lại thành 1 service 2 chế độ
    (`EXTRA_MODE`): `MODE_GEMINI` = Gemini Live làm chính + watchdog 25s
    (không nhận `setupComplete` → tự fallback), lỗi kết nối → fallback, và
    kiểm tra tự động "nghe được tiếng video (im lặng < 60%) nhưng Gemini
    không trả audio trong lúc đã gửi > 200KB" → fallback; `MODE_DEEPSEEK` =
    thẳng pipeline ASR→DeepSeek→TTS. Khi fallback, tải model ASR song song
    từ lúc khởi động nên chuyển gần như tức thì.
  - Giảm độ trễ bám video: hàng đợi dịch "chỉ dịch câu MỚI NHẤT" (bỏ câu cũ
    khi bị chậm) + đợi TTS đọc xong câu trước (callback `onDone` mới của
    `MicrosoftTtsClient`) rồi mới xử lý câu kế.
  - Chống echo: MediaPlayer giọng dịch đặt `USAGE_MEDIA` +
    `ALLOW_CAPTURE_BY_NONE` (không bị projection thu ngược vào ASR/Gemini).
  - `GeminiLiveClient.kt`: thêm `onReadyCallback` (bắn khi nhận setupComplete)
    để watchdog chính xác. MainActivity: provider thứ 3 "DeepSeek Live",
    ô chọn model Gemini, ô "Ngôn ngữ nguồn video" (en/vi/ru/fr/de/es/pt/
    zh-Hans → chọn model Vosk); sửa bug cũ MainActivity không gửi `EXTRA_MODEL`.
  - Build: `gradle :app:compileDebugKotlin` OK → `:app:assembleDebug`
    (52M) + `:app:assembleRelease` (50M) ký `tool/keystore/livedub.keystore`
    (CN=LiveDub, SHA-256 723cf6…); version 0.4 / versionCode 4; APK chứa
    `libvosk.so` 4 ABI (arm64/armv7/x86/x86_64, ~10M/ABI).
  - Lỗi build gặp trong phiên: `sum += if (s < 0) -s else s` với
    `sum: Long` → nhánh `-s`(Int)/`s`(Short) suy ra LUB=Number → compile
    FAILED "None of the following candidates is applicable" → sửa `.toLong()`
    cả 2 nhánh. Dependency Vosk bắt buộc `com.alphacephei:vosk-android:0.3.75`
    (Maven Central) + `packaging.resources.excludes` META-INF để khỏi đụng.

- 2026-08-27 17:50: APP ANDROID "DỊCH VIDEO THỜI GIAN THỰC" (`tool/` —
  `vn.smartdubbing.live`, mã nguồn `tool/app`, KHÔNG thuộc toolkit patchx;
  môi trường build Termux: Gradle 9.7.1 + Java 21 + SDK `~/a`, aapt2 Termux):
  sửa lỗi + thêm tính năng theo yêu cầu người dùng.
  - Lỗi chính đã sửa: thiếu quyền `RECORD_AUDIO` (BẮT BUỘC cho
    AudioPlaybackCaptureConfiguration — app cũ không khai báo nên không bắt
    được audio video); âm thanh dịch phát qua `USAGE_MEDIA` +
    `ALLOW_CAPTURE_BY_NONE` (thay `USAGE_ASSISTANCE_ACCESSIBILITY` — stream
    trợ năng dễ tắt tiếng/sai route trên Honor/Huawei); xin runtime
    `POST_NOTIFICATIONS` (Android 13+); hiển thị trạng thái + lỗi trên UI và
    notification (trước đây lỗi im lặng); chỉ gửi audio sau `setupComplete`;
    xử lý `serverContent.interrupted`; bộ đếm chẩn đoán "Thu KB / Nhận phần /
    Phát KB" cập nhật mỗi 2 giây.
  - Cấu hình Gemini Live đã đối chiếu tài liệu chính thức + forum Google:
    model `gemini-3.5-live-translate-preview`, endpoint
    `BidiGenerateContent`, setup gồm `responseModalities:["AUDIO"]` +
    `translationConfig{targetLanguageCode, echoTargetLanguage}` — ĐÚNG chuẩn.
  - Thêm công cụ dịch DeepSeek (`DeepSeekClient.kt`): POST
    `{baseUrl}/chat/completions` (mặc định `https://api.deepseek.com`, model
    mặc định `deepseek-chat`; ô cấu hình model + base URL + API key trong app).
  - Giọng đọc Microsoft MIỄN PHÍ (`MicrosoftTtsClient.kt`): Edge TTS qua
    WebSocket `speech.platform.bing.com/.../edge/v1` + `TrustedClientToken`
    + header `Sec-MS-GEC` (SHA256 của `{ticks}{skew}{token}`,
    ticks = (unix+11644473600)*1e7) → MP3 `audio-24khz-48kbitrate-mono-mp3`
    → MediaPlayer; giọng Neural tự chọn theo ngôn ngữ đích
    (vi-VN-HoaiMyNeural, en-US-AriaNeural, ja-JP-NanamiNeural...); Android
    TTS chỉ làm fallback.
  - Build: `gradle :app:assembleDebug` / `:app:assembleRelease` từ `tool/`;
    release ký sẵn bằng `tool/keystore/livedub.keystore` (alias livedub,
    pass livedub2026); version 0.3 (versionCode 3).
  - Lưu ý build Termux: OkHttp 4.12 `response.code()` là deprecation →
    phải dùng thuộc tính `response.code`, không thì compile FAILED.


- 2026-08-21 21:40: LƯU TỔNG HỢP BÀI HỌC cho phiên sau — bổ sung
  `outputs/behavior/fake_server/TRACE_HI_TRANSLATE.md` mục 9–11: chuỗi 9
  bypass đã thử theo thời gian (fake server → login → purchaser → trial →
  hết vòng lặp redirect → token VIP → thanh toán thật) + trả lời câu hỏi
  "thanh toán thật có mod thời gian không" (KHÔNG — mục 10) + bài học truy
  vết/xử lý (mục 11). Thêm mục 9 vào file này. Xác lập quy tắc: mọi phiên
  xử lý file/dữ liệu phải ghi phát hiện mới vào file trạng thái + trace.

- 2026-08-21 21:30: BYPASS VIP Hi Translate (com.zaz.translate 6.0.9.005)
  TRÊN VM — CHỐT KẾT QUẢ CUỐI (chi tiết trace: `outputs/behavior/fake_server/
  TRACE_HI_TRANSLATE.md`):
  - ĐÃ XONG: hết vòng lặp login/thanh toán — chặn `wd8.ua` (SecurityPolicy
    BroadcastReceiver), `vd8.ua` (SecurityPolicyActivity.Companion),
    `x48.ud` (routeToLoginRemindDialog), `x48.uh` (routeToSubscriptionDialog/
    TryLimitDialog) → app vào được MainActivity + dialog chọn model
    (Tiêu chuẩn/Gemini-3.5/GPT-5/Deepseek-v4). Script tổng hợp:
    `outputs/behavior/fake_server/vip_master_full.js`.
  - GIỚI HẠN THẬT: VM giờ CÓ MẠNG (ping 8.8.8.8 OK, curl api.translasion.com
    → 200). App gọi `/enhance/dictionary` → server trả `code:1002,
    token:vip-bypass-token-0001 失效` → TOKEN GIẢ BỊ SERVER TỪ CHỐI. Dịch
    model AI → dialog "Đã đạt đến giới hạn sử dụng" (request thật fail).
    `xw3` (HDSubscriptionRep) CHỈ CÓ code + isSubscribed (boolean), KHÔNG có
    field thời gian → không mod được thời gian client-side; server tự
    re-validate token với Google Play mỗi lần (isHDSubscriptionUser).
  - KẾT LUẬN: bypass client chỉ mở UI VIP; tính năng dịch AI server-side
    KHÔNG bypass được. Thanh toán thật chỉ mở server-side trong thời hạn
    subscription (token thật = Google Play purchaseToken, lưu qua
    `com.zaz.subscription.manager.ua.ub(hdPid, hdToken)`).
  - SCRIPT MỚI: `purchase_capture.js` (bắt np.ub + ua.ub THẬT, không fake —
    để test thanh toán thật lấy dữ liệu server).

- 2026-08-21 19:52: KHỞI TẠO GIT + PUSH LÊN GITHUB — repo local `master`, commit đầu `125a7a3` (241 file, ~47K dòng), push lên `https://github.com/anhcanem-z/Behavior-.git`; `.gitignore` loại `outputs/`, `dist/`, `Apks/`, `.codex/`, `libso/`, `libso_clean/`, `patchx_core/patchx_core/` (bản nhân đôi cũ); remote origin set URL sạch (không kèm token).
- 2026-08-21 18:50: TEST THỰC TẾ TRÊN VM (Tailscale 100.64.170.99, Android 12
  arm64, LXC kernel 5.10.110; adb 5555 + Termux ssh 8022 pass 123456; root =
  `su` trong Termux VM; frida-server 17.9.10 root chạy qua ssh session giữ
  mạng). Frida CLI local bị lỗi native `_Py_NoneStruct` (python3.14) — fix
  bằng `LD_PRELOAD=libpython3.14.so`. KẾT QUẢ:
  - Server fake `outputs/behavior/fake_server/fake_api_server.py` chạy local
    127.0.0.1:8000 + `adb reverse tcp:8000` → app gọi API qua
    `redirect_hook.js` (hook `Retrofit$Builder.baseUrl(String)`): APP ĐÃ GỌI
    `GET /enhance/config` → nhận `show_purchase_tab:true` (log server ghi
    nhận). `subnet/check`-style endpoint trả `status:1` + UserInfo uid=1.
  - BYPASS THỜI GIAN TRIAL: hook `SubscriptionActivity.access$countDownLeft`
    trả 30 ngày (`trial_bypass.js`) — countdown Upgrade PRO hiển thị
    `719999:59:59` (≈30 ngày) thay vì ~1 giờ; hook fire mỗi tick. Ảnh:
    `outputs/behavior/fake_server/trial_bypass_screen.png`.
  - VM có Google account sẵn (thuataiz1/hokinhri/xinyeuem1999@gmail.com) —
    luồng Google login/Play billing tự bật khi mở trang PRO; app data bị
    wipe khi user cài lại bản login-bypass (uid app a118→a119).
  - Frida frida-server bị chết nhiều lần khi chạy `nohup ... &` qua ssh —
    giải pháp ổn định: chạy frida-server trong ssh session riêng (foreground).
- 2026-08-21 18:20: quét API Hi Translate (com.zaz.translate 6.0.9.005)
  trên cây `outputs/apk/apk-trees/app` — tìm thấy base API
  `https://api.translasion.com/` (test: `test.translasion.com`, chọn qua
  `ExtKt.ug()`/`overrideIsDebugHost`); interface Retrofit `Lnp;` (smali_classes4/
  np.smali) 10 endpoint: htcenter/account/login|loginwithemail|detail|name/set,
  htcenter/subscription/check|update, htcenter/transaction/update,
  enhance/user/subscription (trả `HDSubscriptionRep.result.isSubscribed`),
  enhance/config (trả `SubscriptionConfig.show_purchase_tab`),
  user/delete_account. Manifest `usesCleartextTraffic=true`, account service
  KHÔNG có cert pinner. Đã dựng BỘ SERVER FAKE lấy isvip tại
  `outputs/behavior/fake_server/`: `fake_api_server.py` (HTTP, trả login
  uid=1 + subscription/check status=1 + isSubscribed=true + show_purchase_tab=
  false, log request) — test thực tế 5 endpoint trả JSON đúng schema;
  `redirect_hook.js` (Frida: đổi baseUrl Retrofit + fallback OkHttp);
  `api_scan_report.md` + `README.md` (3 cách: lừa app = fake server + Frida
  redirect — khả thi nhất; patch smali baseUrl; lừa server thật — KHÔNG khả
  thi vì cần purchase token hợp lệ trên Google Play). node --check + py_compile
  đều OK.

- 2026-08-21 18:08: quét lại theo hành động cũ (mục 3) — `selfcheck`
  8/8 module OK, 60 patch đọc được, 0 lỗi; `index upgraded -o
  outputs/scan` = 60 patch, 60 hợp lệ, 0 vấn đề; `audit upgraded -o
  outputs/audit` = 60 patch, 0 lỗi / 18 cảnh báo / 17 tự sửa được
  (audit.json generated 18:08:02). Đồng bộ số liệu lệch: `Apks/` 7 APK
  (thêm test.apks), `combos_success.json` 4 lượt, cây giải mã 2
  (app 699M + app1 377M), dist mới nhất v10.
- 2026-08-21 17:00: test.apks + app.apk — chuyển sang BYPASS VIP/LOGIN
  (Hi Translate com.zaz.translate 6.0.9.005):
  - test.apks = bundle APKPure (base.apk + split arm64 + xxhdpi), app họ
    com.transgull.*/com.mvp.* (translator): 31 lib arm64 (Microsoft Speech,
    ffmpeg, vlc, python, qjs, opencc, mediapipe...) — KHÔNG có lib bảo vệ
    native; dex có Play Integrity + check signature (chuẩn app thường).
  - app.apk = Hi Translate đã nhúng Frida Gadget (listen 127.0.0.1:27042,
    on_load=wait) + script 2439 hook bypass Pro/VIP/login
    (GLOBAL_VIP_OVERRIDE/SSL/FAKE_LOGGED_IN/LOGIN_BYPASS/SKIP_LOGIN_GATE=true)
    — nhưng bản này HỎNG: `VerifyError: WelcomeActivity.<clinit>` (register
    uninitialized, patch smali lỗi) -> app crash ngay khi launch.
  - Bản đồ logic VIP/login (từ cây giải mã outputs/apk/apk-trees/app):
    isLogin = AppImpl.isLogin -> (UserInfo != null && uid > 0);
    SubscriptionManager = com/zaz/subscription/manager/ua (R8) —
    ui()Z/uc()Z/ug()Z/uh()Z/ue()Z; AccountService = com/zaz/account/uc —
    uf()=getUserInfo, ui()Z=has-subscription; UserInfo ctor
    (J uid, name, email, avatar, phone, provider, aid, token, nameNeedVerify).
  - Script `outputs/behavior/rodata_test/vip_login_bypass.js`: fake UserInfo
    (uid=1 + token giả) qua Acct.uf + ép isLogin + SM.ui/uc/ug/uf/uh/ue +
    Acct.ui = true + chặn LoginBottomDialogActivity.start/onCreate.
    LƯU Ý: phải `Java.cast(fake, UserInfo)` khi trả về từ hook — không cast
    Frida báo "expected return value compatible with com.zaz.account.UserInfo"
    và app crash. Đã test trên VM: hooks fire (SM.uh 25+, SM.ue/uf/ui,
    Acct.ui), app sống; vẫn dừng ở LoginBottomDialogActivity khi chưa fake
    UserInfo (giờ đã fake + cast OK).
  - frida-server 17.9.10 arm64: SEGFAULT (sig11) khi SPAWN com.zaz.translate
    (3 lần, dmesg ghi nhận) — dùng ATTACH hoặc Gadget thay thế.
  - VM Tailscale 100.64.170.99: ping OK nhưng SSH port 8022 refused sau
    reboot — cần bật sshd trong Termux trên VM.
- 2026-08-21 16:37: app1.apk (MT Manager bin.mt.plus 2.26.8) — KẾT LUẬN
  BYPASS libmtprotect.so + nâng cấp từ điển hành vi (smart_ontology):
  - Stub sạch (`libmtprotect_clean.so`): cài được nhưng app CRASH —
    `UnsatisfiedLinkError: No implementation found for void l.ۢ.<clinit>()`
    (lib gốc chứa natives thật của lớp shell, stub không có).
  - Patch tĩnh PLT `abort->ret` (`libmtprotect_abortnop.so`, 378 call-site
    abort trong lib): VẪN CRASH — quyết định không nằm ở abort.
  - remote-observe (frida-server 17.9.10 trên VM Tailscale 100.64.170.99,
    root; kết nối `-H 100.64.170.99:27042`): JNI_OnLoad đọc
    `/proc/self/maps` + `base.apk`, TRẢ 0x10006 (thành công) nhưng BỎ QUA
    RegisterNatives khi chữ ký lệch -> crash; bản gốc chạy tốt (activity
    `MainLightIcon` hiển thị). Không thấy gọi vtable JNIEnv index 215 —
    nghi dùng ART nội bộ (`ClassLinker::RegisterNative`).
  - ĐIỂM QUYẾT ĐỊNH = xác minh chữ ký chặn đăng ký natives (không phải
    abort); bypass cần patch nhánh trước RegisterNatives hoặc thay hash
    chứng chỉ nhúng.
  - Nâng cấp `smart_ontology.py`: +7 hành vi MT Protect
    (`signature_verify_gate`, `jni_onload_stealth_fail`,
    `native_register_art_internal`, `abort_plt_many_sites`,
    `reads_own_apk_integrity`, `reads_proc_self_maps`,
    `jni_payload_activation`) + 6 ánh xạ category
    (signature/integrity/tamper/antidebug/native/shell). Test:
    `test_smart_ontology` 29/29, `test_smart_scanner` 26/26,
    `test_behavior_aux_modules` 4/4.
  - Scripts giữ lại: `outputs/behavior/rodata_test/observe_mtprotect.js`,
    `probe_art_register.js`, `bypass_all_libs.js`; lib/APK đã build:
    `outputs/apk/apk-patch/libmtprotect_abortnop.so`,
    `app1_orig_resigned.apk`, `app1_abortnop_signed.apk`.
- 2026-08-21 17:45: tiếp tục bypass — tạo bộ lib ĐÃ BYPASS hoàn
  chỉnh `libso_clean/` (11 lib): `libmtprotect.so` = stub sạch
  (JNI_OnLoad trả JNI_VERSION_1_6, 5.4 KB), 10 lib còn lại giữ
  gốc (libhook/mt1/mt2/mt3 có Java_* natives của app — không
  stub). Kèm `README.txt` hướng dẫn thay trong cây APK + build.
  Frida runtime: `bypass_all_libs.js` (chặn kill + so sánh cho
  mọi lib mt/hook/protect/lsplant). Backup gốc:
  `outputs/backup/libmtprotect.so.orig`.
- 2026-08-21 17:35: thêm QUY TẮC ĐỒNG BỘ TỰ ĐỘNG vào `AGENTS.md`
  (mục mới): mỗi khi thêm tính năng/nâng cấp phải cập nhật đồng
  thời cli.py/patchx/patchx_toolkit.py, HUONG_DAN_*.txt, tests,
  SMART_BEHAVIORS (nếu hành vi đã học muốn dùng vĩnh viễn),
  NAVIGATION.json, outputs/README.md, dist/.
  - `tools/sync_modules.py` — kiểm tra tự động: lệnh cli.py ↔ tài
    liệu, module behavior ↔ test, kho discovered ↔ từ điển gốc,
    mtime code ↔ AGENTS_TRANG_THAI.md (chỉ in thiếu sót).
  - Bổ sung test `test_behavior_aux_modules` (4/4 pass) cho
    frida_generator/crypto_interceptor/gadget_pipeline/
    remote_controller — sync_modules giờ OK, selfcheck 8/8.
- 2026-08-21 17:15: đồng bộ hành vi TỰ PHÁT HIỆN sang MỌI module
  smart_scan: `smart_ontology.all_behaviors()` gộp từ điển gốc +
  kho discovered; `get_behavior()` nhận cả id mới; catalog in kèm
  nhãn `[TỰ PHÁT HIỆN]`; behavior_learner dùng chung nguồn biết
  (không báo trùng). Test: học `anti_debug` -> get_behavior/catalog
  nhận ngay; test_smart_ontology + test_smart_scanner = 51/51 pass;
  selfcheck 8/8.
- 2026-08-21 17:00: thêm cơ chế TỰ ĐỘNG học hành vi mới:
  `patchx_core/behavior/behavior_learner.py` — sau mỗi lần
  `smart-scan`/`start-scan`, rà finding gom behavior.id/category
  lạ (ngoài `SMART_BEHAVIORS`) ghi vào
  `outputs/behavior/discovered/behaviors.json` + `behaviors_<nguồn>.json`;
  `all_behaviors()` gộp từ điển gốc + kho phát hiện để lần quét
  sau nhận diện luôn. Test: behavior lạ `integrity_check` → lần 1
  ghi, lần 2 không trùng; selfcheck 8/8; KHÔNG tự sửa từ điển gốc.
- 2026-08-21 16:35: vô hiệu hóa mtprotect LUÔN (không tìm điểm
  quyết định):
  - Frida runtime `outputs/behavior/rodata_test/bypass_mtprotect_disable.js`
    — chặn abort/__assert2/android_set_abort_message/exit/_exit/
    raise/pthread_kill/kill/syscall(tgkill) + memcmp/strcmp/strncmp
    trả 0 khi caller trong lib bảo vệ + fake property
    (ro.debuggable=0, ro.secure=1...).
  - Thư viện SẠCH thay thế: `outputs/behavior/rodata_test/libmtprotect_clean/`
    (stub C, build = aarch64-linux-android-clang -shared; 5.4 KB,
    JNI_OnLoad trả JNI_VERSION_1_6 — verify bằng ctypes = 0x10006,
    export __cxa_atexit/__cxa_finalize/abort(loop)/__assert2).
  - Bản thay thế sẵn: `libso/stub/libmtprotect.so`; backup gốc:
    `outputs/backup/libmtprotect.so.orig`.
- 2026-08-21 16:20: phân tích `libso/libmtprotect.so` (Legu/MT
  shell): JNI payload = `JNI_OnLoad` RVA 0x127478 (169 KB); luồng
  xác minh = `__openat_2`/read/lseek + so sánh magic (movk 32-bit)
  + `mprotect` tự giải mã (0x17a-0x181) + `abort` khi fail; chuỗi
  bị mã hóa, imports ẩn qua PLT. KHÔNG patch tĩnh (self-check CRC).
  Đã tạo Frida bypass runtime:
  `outputs/behavior/rodata_test/bypass_mtprotect_integrity.js`
  (hook abort/memcmp/strcmp/__system_property_get/__openat_2 theo
  caller trong lib bảo vệ).
- 2026-08-21 15:55: CÀI FRIDA cho Termux — dùng wheel có sẵn
  `frida-termux-build/frida-17.9.10-cp37-abi3-*.whl` (bản mới
  từ PyPI build fail: toolchain build.frida.re toàn 404); cài
  `frida-tools` 14.10.4 + colorama/prompt_toolkit/pygments/
  websockets. LƯU Ý: binding cần symbol `_Py_NoneStruct` không
  thấy khi dlopen -> mọi lệnh phải chạy với
  `LD_PRELOAD=libpython3.14.so` (wrapper: `tools/frida_env.sh`);
  `frida-ps` local cần root (không có trên Termux) — dùng hướng
  gadget (`libgadget.so` sẵn trong outputs/behavior/gadget/).
- 2026-08-21 15:35: chuyển 4 test sang dùng fixture mẫu
  `tests/fixtures/mau/`: `test_rodata_patcher` (libdemo64/
  32/libdup), `test_rodata_bypass_flows` (libdemo64),
  `test_start_scan` (libmini_a/b/c), `test_smart_scanner`
  (libsmart — ELF ARM64 có .text/.dynsym) — bỏ hàm dựng ELF
  cục bộ trong test, copy fixture sang TMP trước khi patch;
  chạy riêng 81/81 pass.
- 2026-08-21 15:21: bổ sung bộ fixture MẪU `tests/fixtures/mau/`
  (`generate_mau.py` tái sinh: `libdemo64.so`/`libdemo32.so` ELF
  giả có .rodata, `smali_tree/` cây APK nhỏ, `patch_mau.zip` patch
  mẫu) + `README.md` hướng dẫn + test `test_fixtures_mau`
  (5/5 pass, chạy riêng) — dùng chung cho rodata_patcher/
  rodata_bypass/start_scan/smart_scanner thay vì tự dựng trong TMP.
- 2026-08-21 14:33: hoàn tất SMART SCANNER 4 trụ cột —
  `patchx_core/behavior/smart_scanner.py` (lọc nhiễu ngữ nghĩa + data-flow
  tĩnh ADRP+ADD/LDR literal/LEA rip + xác thực chéo JNI + Risk Weighting/
  Confidence 0-100 kèm EVIDENCE + SHA-256 repro) + `smart_ontology.py` (từ
  điển hành vi giống ontology.py, 14 hành vi, `--behaviors` để in) + lệnh
  `patchx smart-scan` + `patchx start-scan` (start-scan = xử lý THƯ VIỆN lib
  .so HÀNG LOẠT từ APK/theo ABI; behavior = smali — tách biệt 2 luồng); menu
  phân chia NHÁNH NATIVE/SMALI/CHUNG có hệ thống; test riêng 119/119 pass;
  test thật trên `Apks/app1.apk` (11 lib arm64): 6085 chuỗi, 581 finding,
  5022 refs (321 JNI), 956 nhiễu; báo cáo
  `outputs/behavior/smart_scan/start_scan_app1.*`.
- 2026-08-21 14:12: `python3` (Termux) đã sửa xong — verify `python3 --version`
- 2026-08-21 14:12: `python3` (Termux) đã sửa xong — verify `python3 --version`
  = Python 3.14.6, `python3 patchx selfcheck` = 8/8 module OK, 60 patch,
  0 lỗi; cập nhật mục 5 (bỏ ghi chú "python3 hỏng") + mục 6 (bỏ việc cần
  sửa); từ nay mọi lệnh trong toolkit chạy bằng `python3` bình thường.
- 2026-08-21 13:32: đóng gói lại `dist` bản 6 (11.33 MB, kèm `rodata-apply`;
  xóa bản 3, giữ 3 bản).
- 2026-08-21 14:00: đóng gói lại `dist` bản 9 (11.34 MB, kèm
  `feature_menu.py` + lệnh `patchx menu`; xóa bản 6, giữ 3 bản).
- 2026-08-21 14:05: thêm `patchx_core/feature_menu.py` + lệnh `patchx menu` —
  DANH SÁCH CHỨC NĂNG để lựa chọn pipeline: 19 chức năng nhóm theo bước
  luồng (chuẩn bị -> phân tích -> bypass/patch -> áp -> build -> kiểm tra),
  đánh số liên tục; `--goal` tính điểm khớp từ khóa và xếp hạng; `--run ID`
  chạy pipeline đúng thứ tự (placeholder `{KEY}` thay bằng `--set` hoặc hỏi
  tương tác); `test_feature_menu` 19/19; tổng 59/59; test thật `patchx menu
  --goal "frida ram patch"` xếp rodata-dynamic đầu; docs README/AGENTS.
- 2026-08-21 13:54: đóng gói lại `dist` — bản 7 thiếu
  `rodata_bypass_main.py` (danh sách `included` trong `cmd_package` không
  khai báo) nên đóng gói lại bản 8 (11.34 MB, đủ cả 2 file; xóa bản 5).
- 2026-08-21 13:54: đóng gói lại `dist` bản 7 (11.34 MB, kèm
  `rodata_bypass/` + `rodata_bypass_main.py`; xóa bản 4, giữ 3 bản).
- 2026-08-21 13:40: thêm BỘ BYPASS RIÊNG — `patchx_core/rodata_bypass/`
  (thư mục module riêng: static_flow + dynamic_flow + main + __main__) +
  `rodata_bypass_main.py` (main hiển thị riêng ở root); 2 thành phần tách
  biệt: luồng TĨNH (--flow static, patch file) và luồng ĐỘNG (--flow
  dynamic, Frida RAM); `test_rodata_bypass_flows` 11/11 + `test_rodata_patcher`
  29/29 = 40/40; test thật trên liblsplant.so (app1.apk) cả 2 luồng; docs
  mục 14.
- 2026-08-21 13:32: bổ sung `rodata-apply` — patch chuỗi TRỰC TIẾP vào
  file `.so` (`rva_to_file_offset` + `patch_so_file`: backup
  `outputs/backup/rodata_apply/`, NUL hóa phần dư, chặn tràn trừ
  `--allow-overflow`, `--out` ghi bản mới; từ chối pointer/runtime_scan);
  test thật trên `liblsplant.so` (app1.apk) đủ 6 tình huống — ghi ngắn hơn
  + verify, chặn dài hơn, overflow, `--out`, backup khớp SHA-256, file gốc
  không đụng; `test_rodata_patcher` 29/29; báo cáo bổ sung
  `outputs/behavior/rodata_test/report.md`; docs mục 13.
- 2026-08-21 13:31: test rodata trên APK thật `Apks/app1.apk` (APK mới,
  32M, thêm 13:27) — trích 11 lib arm64-v8a + 1 lib armeabi-v7a vào
  `outputs/behavior/rodata_test/so/`; `rodata-find`/`rodata-patch` chạy đúng
  trên ELF64 lẫn ELF32 (liblsplant.so, chuỗi `map::at:  key not found`,
  rva=0x1ff9/0x1549); bổ sung cảnh báo generation-time khi inline dài hơn
  chuỗi cũ (khuyên `--mode pointer`); báo cáo
  `outputs/behavior/rodata_test/report.md`. APK này chứa lib hook/bảo vệ,
  không có URL API trong .rodata. `test_rodata_patcher` vẫn 18/18.
- 2026-08-21 13:26: đóng gói lại `dist` bản 5 (11.32 MB, chứa
  `rodata_patcher.py` + 2 lệnh mới + test + docs; xóa bản 2, giữ 3 bản).
- 2026-08-21 13:24: thêm kỹ thuật ro.data patching bằng Frida —
  `patchx_core/behavior/rodata_patcher.py` (ELF parser: file offset → RVA qua
  section header + fallback PT_LOAD; tìm chuỗi trong `.rodata`/`.data`; sinh
  script Frida inline/pointer/both + runtime-scan, bảo vệ trang + khôi phục
  quyền); 2 lệnh mới `rodata-find`/`rodata-patch` trong `patchx_core/cli.py`;
  test `test_rodata_patcher` 18/18 pass (ELF64 + ELF32 giả + script JS); docs
  `HUONG_DAN_BEHAVIOR_FRIDA.txt` mục 12 + `README.md` + `AGENTS.md`;
  `sync_patchx.py` SMOKE_MODULES thêm `rodata_patcher`; ghi nhận `python3`
  hỏng trên Termux (dùng `python3.12`).
- 2026-08-21 09:50: đồng bộ chính xác chuỗi đường dẫn còn lại —
  `patchx_toolkit.py` (bỏ `real_apk_test`, keystore/signed-apk trỏ
  `outputs/apk/apk-patch/`), `HUONG_DAN_GADGET.txt` (gadget_out →
  `outputs/behavior/gadget`, behavior_out → `outputs/behavior`),
  `HUONG_DAN_LENH.txt`/`HUONG_DAN_BEHAVIOR_FRIDA.txt` (ví dụ cây →
  `outputs/apk/apk-trees/app`), `.gitignore` (bỏ tên thư mục cũ),
  `NGU_CANH.md` (toolkit_out → outputs/pipeline); đóng gói lại dist v4.
- 2026-08-21 09:45: hoàn tất dọn dẹp phát hành — xóa `__pycache__`,
  `*.bak` (cli/cfg/detector/target/app.apk + .bak trong apk-build/gadget),
  `_help.*`, `libgadget.so` trùng hash, `cli_fixed.py` (chuyển
  `outputs/backup/`), output cũ lẫn trong `upgraded/`; chạy `audit` 60 patch
  0 lỗi/18 cảnh báo; `package` tạo dist 3 bản; `selfcheck` 8/8 module.
- 2026-08-21: tạo file trạng thái lần đầu cho bản behavior+Frida; thiết lập
  `outputs/` theo module + đồng bộ source (`patchx_core/cli.py`, baseline,
  advisor, learn, behavior/*, `patchx_toolkit.py`); backup gốc tại
  `outputs/backup/pre_sync_20260821/`; dọn cache sim cũ; giữ 3 file
  `HUONG_DAN_*.txt` và đưa vào gói phát hành.

---

## 9. BÀI HỌC TRUY VẾT + XỬ LÝ (tổng hợp từ phiên Hi Translate)

Chi tiết đầy đủ: `outputs/behavior/fake_server/TRACE_HI_TRANSLATE.md`
(mục 9–11 = chuỗi bypass đã thử + trả lời thanh toán thật + bài học).

- 2026-08-27: BÀI HỌC PairIP (`com.pairip.*` — license check của app
  `com.sota.aitranslatex`): cấu trúc thật gồm `Application.attachBaseContext`
  + `LicenseContentProvider.onCreate` gọi `LicenseClient.checkLicense` (2 entry
  point duy nhất bên ngoài package), `LicenseActivity` (PAYWALL/ERROR_DIALOG)
  tự thoát app, `LicenseClient.stopTrial`/`handleTrialEnd`/`initializeLicenseCheck`
  = luồng hết trial (3 phút) -> paywall. Bản này KHÔNG có lib native
  (`libpairipcore.so`) nên chỉ cần vá smali; khi gặp bản có lib native phải
  kiểm tra thêm `lib/` + hook .so (RVA) — ghi nhớ từ lệnh `pairip-bypass`
  mới (báo cả `native_libs`). Vá đủ 7 điểm như mô tả ở mục 8 (2026-08-27
  23:14); thử lại lần 2 = idempotent (0 thay đổi).

- 2026-08-27: Bài học app Android dịch giọng (project `tool/app`): (1)
  playback capture audio BẮT BUỘC có `RECORD_AUDIO` (runtime) + MediaProjection
  consent, thiếu là SecurityException/im lặng; (2) khi tự phát âm thanh lúc
  đang capture phải dùng `USAGE_MEDIA` + `ALLOW_CAPTURE_BY_NONE` để nghe được
  mà không vọng; (3) Edge TTS free = WebSocket Bing + Sec-MS-GEC, không cần
  API key — dùng được khi DeepSeek/Gemini chỉ trả text.

### 9.1 Bản đồ lớp chặn VIP (thứ tự truy vết khi app server-side)

Network gate (`ua.ue`/`ActivityKtKt.uv`) → Login (`uc.uf/ui`, `AppImpl.isLogin`)
→ Purchaser (`ug.uf` trả `List<Purchase>`) → Subscription API (Retrofit
`np.ub` → `xw3` code+isSubscribed) → SM state (`subscription.manager.ua`:
hdPid/hdToken/isHDVip, `uo(true)`) → Limit/security redirect (`wd8.ua`,
`vd8.ua`, `x48.ud` routeToLoginRemindDialog, `x48.uh`
routeToSubscriptionDialog/TryLimitDialog). Bỏ lớp nào cũng dính redirect
login/thanh toán — phải chặn ĐỦ cả chuỗi.

### 9.2 Giới hạn kỹ thuật đã chứng minh (không thử lại)

- Retrofit interface (`ApiService`, `np`) KHÔNG hook được trực tiếp — dynamic
  proxy không qua implementation → chặn ở tầng caller (`wd8.ua`/`x48.*`).
- okhttp bị R8 obfuscate (`ClassNotFoundException RealCall`) — không hook tầng
  network thư viện.
- Server-side check: token giả bị từ chối (`code:1002 失效`) — `xw3` không có
  field thời gian — server re-validate purchaseToken với Google Play mỗi lần →
  "bypass thời gian" KHÔNG khả thi, chỉ thanh toán thật mới mở server-side
  đúng thời hạn Google quản lý.
- Frida REPL `%load` xóa toàn bộ state — luôn paste JS trực tiếp.
- Hook trả object interface: bắt buộc `Java.cast(obj, Cls)` bên trong
  `implementation`, không cast → crash.

### 9.3 Môi trường VM (tái sử dụng cho lần sau)

- VM Tailscale `100.64.170.99` (Android 12 arm64, LXC kernel 5.10.110):
  adb `100.64.170.99:5555` — Termux ssh `-p 8022` pass `123456` — root = `su`
  trong ssh session.
- frida-server 17.9.10 root: chạy FOREGROUND trong ssh session riêng (nohup
  hay chết) — SPAWN com.zaz.translate bị SIGSEGV → dùng ATTACH.
- Frida CLI local Termux: `LD_PRELOAD=/data/data/com.termux/files/usr/lib/
  libpython3.14.so`.
- Cây smali chính xác nhất bản VM: `outputs/apk/vm_build/smali/`.
- KIỂM TRA MẠNG VM trước khi kết luận bypass fail — "not connected" là gốc
  rễ vòng lặp login/thanh toán.

### 9.4 App dịch video thời gian thực (`tool/`) — vì sao "Gemini không nhận dữ liệu"

- Nguyên nhân thường gặp khi app thu audio nhưng Gemini im lặng: (1) model
  `*-live-translate-preview` là PREVIEW — API key không có quyền/geo-restricted
  → server từ chối (đọc mã lỗi trong `filesDir/live_dub_debug.log`);
  (2) video DRM (Widevine L1) KHÔNG capture được dù projection OK → thu toàn
  im lặng; (3) thiếu quyền `RECORD_AUDIO` (AudioPlaybackCapture bắt buộc);
  (4) app nguồn phát audio với usage không khớp (đã thêm USAGE_UNKNOWN).
- Cách chẩn đoán nhanh: mở `live_dub_debug.log` (300 dòng cuối) — xem dòng
  "AudioRecord.read", "setupComplete", "Gemini error (mã ...)".
- Vosk: `acceptWaveForm=true` chỉ trả câu khi kết thúc → độ trễ ASR ~ thời
  lượng 1 câu; `partialResult` cho chữ đang nghe (chỉ hiển thị, không dịch
  để tránh dịch cụm cụt). Model tiếng Việt: `vosk-model-small-vn-0.4`.
- Độ trễ thấp nhất = Gemini Live (audio→audio, không chờ hết câu); pipeline
  ASR→DeepSeek→TTS trễ ~ hết 1 câu + dịch + TTS nên chỉ dùng làm fallback/
  chế độ DeepSeek Live. DeepSeek: dùng `deepseek-chat` (nhanh), KHÔNG dùng
  `deepseek-reasoner` cho realtime.
- Tối ưu trễ thật đã chứng minh trên VM 2026-08-27 (v0.17):
  (1) `waitForAndroidTts` từng chờ 2,5s MỖI chunk khi máy không có engine TTS
  — fix bằng cờ `androidTtsChecked`, lần sau bỏ hẳn chờ;
  (2) dịch phải chạy SONG SONG với TTS — tách `translationLoop` (không await
  phát) khỏi `speakLoop` (phát tuần tự, chờ onDone) — trước đây TTS phát xong
  mới dịch đoạn kế;
  (3) Google `translate_tts` render sẵn theo `ttsspeed` — lần đầu tải mất
  1-3s, dùng cache md5 `(lang|speed|text)` + streaming để lặp lại phát ngay;
  (4) OCR chỉ cần vùng crop — `readCropFromImage` đọc thẳng buffer thay vì
  copy full-frame rồi crop (tiết kiệm ~70%);
  (5) backlog TTS khi OCR nhanh hơn phát: bỏ đoạn cũ, ưu tiên nội dung mới
  nhất đang hiển thị để bám video 1:1 (log "Giọng đọc chậm hơn nội dung").
- UI automation VM (spinner chọn mode): tap spinner → `input keyevent 20`
  x4-5 (cuộn dialog tới OCR) → tap mục "OCR — đọc chữ hiện trên video" →
  `input keyevent 93` (PAGE_DOWN xuống nút) → tap "▶ BẮT ĐẦU ĐỌC CHỮ TRÊN
  VIDEO". Spinner KHÔNG giữ lựa chọn qua force-stop (mỗi lần test phải chọn
  lại). Dùng `su -c "cat /data/data/vn.smartdubbing.live/files/live_dub_debug.log"`
  để đọc log (có root, không cần run-as).
